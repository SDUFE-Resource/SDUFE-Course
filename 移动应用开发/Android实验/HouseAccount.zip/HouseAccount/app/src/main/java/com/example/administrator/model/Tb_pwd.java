package com.example.administrator.model;

public class Tb_pwd {
    private String pwd;

    public Tb_pwd(){
        super();
    }
    public Tb_pwd(String pwd){
        super();
        this.pwd=pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getPwd() {
        return pwd;
    }
}
