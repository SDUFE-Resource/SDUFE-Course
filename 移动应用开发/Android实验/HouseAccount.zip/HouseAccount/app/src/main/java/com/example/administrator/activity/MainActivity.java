package com.example.administrator.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] titles=new String[]{"新增支出","新增收入","我的支出","我的收入",
                "数据管理","系统设置","收支便签","帮助","退出"}; //定义字符串数组，存储系统功能的文本
        int[] images=new int[]{R.drawable.addoutaccount,R.drawable.addinaccount,
                R.drawable.outaccountinfo,R.drawable.inaccountinfo,R.drawable.showinfo,
                R.drawable.sysset,R.drawable.accountflag,R.drawable.help,R.drawable.exit};
        List<Map<String,Object>> data = new ArrayList<Map<String, Object>>();
        for(int i=0;i<titles.length;i++){
            Map<String,Object> map = new HashMap<String, Object>();
            map.put("image",images[i]);
            map.put("title",titles[i]);
            data.add(map);
        }
        SimpleAdapter adapter = new SimpleAdapter(this,data,R.layout.gvitem,
                new String[]{"image","title"},new int[]{R.id.imageView,R.id.textView});
        GridView gridView = (GridView)findViewById(R.id.gridview);
        gridView.setAdapter(adapter);
    }
}













