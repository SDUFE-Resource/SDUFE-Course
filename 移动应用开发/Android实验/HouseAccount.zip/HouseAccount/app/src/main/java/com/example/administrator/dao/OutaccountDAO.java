package com.example.administrator.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.administrator.model.Tb_inaccount;
import com.example.administrator.model.Tb_outaccount;

import java.util.ArrayList;
import java.util.List;

public class OutaccountDAO {
    private DBOpenHelper helper;
    private SQLiteDatabase db;

    public OutaccountDAO(Context context) {
        helper = new DBOpenHelper(context);
        db = helper.getWritableDatabase();
    }

    public void add(Tb_outaccount tb_outaccount) {
        ContentValues cv = new ContentValues();
        cv.put("_id",tb_outaccount.get_id());
        cv.put("money",tb_outaccount.getMoney());
        cv.put("time",tb_outaccount.getTime());
        cv.put("type",tb_outaccount.getType());
        cv.put("address",tb_outaccount.getAddress());
        cv.put("mark",tb_outaccount.getMark());
        db.insert("tb_outaccount",null,cv);
    }

    public void update(Tb_outaccount tb_outaccount) {
        ContentValues cv = new ContentValues();
        cv.put("_id",tb_outaccount.get_id());
        cv.put("money",tb_outaccount.getMoney());
        cv.put("time",tb_outaccount.getTime());
        cv.put("type",tb_outaccount.getType());
        cv.put("address",tb_outaccount.getAddress());
        cv.put("mark",tb_outaccount.getMark());
        db.update("tb_outaccount",cv,"_id=?",new String[]{
                String.valueOf(tb_outaccount.get_id())});
    }

    public Tb_outaccount find(int id) {
        Cursor cursor = db.query("tb_outaccount",new String[]{"_id",
                        "money","time","type","address","mark"},
                "where _id=?",new String[]{String.valueOf(id)},
                null,null,null);
        if(cursor.moveToNext()){
            double money = cursor.getDouble(cursor.getColumnIndex("money"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String type = cursor.getString(cursor.getColumnIndex("type"));
            String address = cursor.getString(cursor.getColumnIndex("address"));
            String mark = cursor.getString(cursor.getColumnIndex("mark"));
            return new Tb_outaccount(id,money,time,type,address,mark);
        }
        cursor.close();
        return null;
    }

    public void delete(Integer... Ids) {
        for (int i =0; i<Ids.length;i++) {
            db.delete("tb_outaccount", "where _id=?",
                    new String[]{String.valueOf(Ids[i])});
        }

    }

    public List<Tb_outaccount> getScrollData(int start, int count) {
        List<Tb_outaccount> tb_outaccountList = new ArrayList<Tb_outaccount>();
        Cursor cursor = db.rawQuery("select * from tb_outaccount limit ?,?",new String[]{
                String.valueOf(start),String.valueOf(count)
        });
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            double money = cursor.getDouble(cursor.getColumnIndex("money"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String type = cursor.getString(cursor.getColumnIndex("type"));
            String address = cursor.getString(cursor.getColumnIndex("address"));
            String mark = cursor.getString(cursor.getColumnIndex("mark"));
            tb_outaccountList.add(new Tb_outaccount(id, money, time, type, address, mark));
        }
        cursor.close();
        return tb_outaccountList;
    }

    public int getCount() {
        Cursor cursor = db.rawQuery("select count(_id) from tb_outaccount",null);
        if(cursor.moveToNext())
            return cursor.getInt(0);
        cursor.close();
        return 0;
    }

    public int getMaxId() {
        Cursor cursor = db.rawQuery("select max(_id) from tb_outaccount",null);
        if(cursor.moveToNext())
            return cursor.getInt(0);
        cursor.close();
        return 0;
    }
}
















