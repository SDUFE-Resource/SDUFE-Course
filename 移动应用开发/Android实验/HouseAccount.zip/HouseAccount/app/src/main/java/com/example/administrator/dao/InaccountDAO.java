package com.example.administrator.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.administrator.model.Tb_inaccount;

import java.util.ArrayList;
import java.util.List;

public class InaccountDAO {
    private DBOpenHelper helper;
    private SQLiteDatabase db;

    public InaccountDAO(Context context) {
        helper = new DBOpenHelper(context);
        db = helper.getWritableDatabase();
    }

    public void add(Tb_inaccount tb_inaccount) {
        db.execSQL("insert into tb_inaccount(_id,money,time,type,handler,mark) values(?,?,?,?,?,?)",
                new Object[]{tb_inaccount.get_id(),tb_inaccount.getMoney(),tb_inaccount.getTime(),
                tb_inaccount.getType(),tb_inaccount.getHandler(), tb_inaccount.getMark()});
    }

    public void update(Tb_inaccount tb_inaccount) {
        db.execSQL("update tb_inaccount set money=?,time=?,type=?,handler=?,mark=? where _id=?",
                new Object[]{tb_inaccount.getMoney(),tb_inaccount.getTime(),
                        tb_inaccount.getType(),tb_inaccount.getHandler(), tb_inaccount.getMark(),
                        tb_inaccount.get_id()});
    }

    public Tb_inaccount find(int id){
        Cursor cursor = db.rawQuery("select _id,money,time,type,handler,mark from tb_inaccount where _id=?",
                new String[]{String.valueOf(id)});
        if(cursor.moveToNext()){
            double money = cursor.getDouble(cursor.getColumnIndex("money"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String type = cursor.getString(cursor.getColumnIndex("type"));
            String handler = cursor.getString(cursor.getColumnIndex("handler"));
            String mark = cursor.getString(cursor.getColumnIndex("mark"));
            return new Tb_inaccount(id,money,time,type,handler,mark);
        }
        cursor.close();
        return null;
    }

    public void delete(Integer... ids){
        if(ids.length>0) {
            StringBuffer sb = new StringBuffer();
            for (int i=0;i<ids.length;i++) {
                sb.append('?').append(',');
            }
            sb.deleteCharAt(sb.length()-1);
            db.execSQL("delete from tb_inaccount where _id in ("+sb+")", (Object[]) ids);
        }
    }

    public List<Tb_inaccount> getScrollData(int start, int count) {
        List<Tb_inaccount> tb_inaccountList = new ArrayList<Tb_inaccount>();
        Cursor cursor = db.rawQuery("select * from tb_inaccount limit ?,?",new String[]{
                String.valueOf(start),String.valueOf(count)
        });
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            double money = cursor.getDouble(cursor.getColumnIndex("money"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String type = cursor.getString(cursor.getColumnIndex("type"));
            String handler = cursor.getString(cursor.getColumnIndex("handler"));
            String mark = cursor.getString(cursor.getColumnIndex("mark"));
            tb_inaccountList.add(new Tb_inaccount(id, money, time, type, handler, mark));
        }
        cursor.close();
        return tb_inaccountList;
    }

    public int getCount() {
        Cursor cursor = db.rawQuery("select count(_id) from tb_inaccount",null);
        if(cursor.moveToNext())
            return cursor.getInt(0);
        cursor.close();
        return 0;
    }

    public int getMaxId() {
        Cursor cursor = db.rawQuery("select max(_id) from tb_inaccount",null);
        if(cursor.moveToNext())
            return cursor.getInt(0);
        cursor.close();
        return 0;
    }
}
























